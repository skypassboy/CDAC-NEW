package com.assignment3;

import java.util.Comparator;

public class Manager implements Comparator<Emp>{

	@Override
	public int compare(Emp e1,Emp e2) {
		
		int diff = (int) (e1.getSalary()-e2.getSalary());
		
		if(diff==0) {
			diff = e1.getName().compareTo(e2.getName());
			return (int) diff;
		}
		return (int) diff;
		
		
	}
	
	
	
	
}
